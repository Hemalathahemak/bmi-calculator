import React from "react";
import  ReactDOM  from "react-dom";
import App from "./App";

function Apps(){
    return(
        <App/>
    )
}
ReactDOM.render(<Apps/>,document.getElementById('root'));