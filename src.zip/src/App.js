import React, {useState} from "react";
import './App.css';

function App(){
  const [weight,setweight]=useState(0);
  const [height,setheight]=useState(0);
  const [bmi,setbmi]=useState('');
  const [message,setmessage]=useState('');

  let calculatebmi=(event) =>{
    event.preventDefault();
    if(weight===0 || height===0){
      alert("invalid input");
    }
    else{
      let bmi=(weight / (height / 100) ** 2)
      setbmi(bmi.toFixed(2))

      if(bmi<18.5){
        setmessage("You are Underweight")
      }
      else if(bmi>=18.5 && bmi<=24.0){
        setmessage("You are Healthy Weight")
      }
      else if(bmi>=25 && bmi<=29.9){
        setmessage("You are Overweight")
      }
      else{
        setmessage("You are obsese")
      }
    }
}

let reload=() => {
  window.location.reload();
}
    return(
        <div className="app">
          <div className="container">
            <h2 className="center">BMI calculator</h2>
            <form onSubmit={calculatebmi}>
              <div>
                <label>Weight (Kg)</label>
                <input value= {weight} onChange={(e) => setweight(e.target.value)} />
              </div> 
              <div>
                <label>Height (Cm)</label>
                <input value= {height} onChange={(e) => setheight(e.target.value)} />
              </div>
              <button className="btn" type="submit">Submit</button>
              <button className="btn btn.outline" type="submit" onClick={reload}>Reload</button>
            </form>
            <div className="center">
            <h3>Your BMI is {bmi}</h3>
            <p>{message}</p>
            </div>
          </div>
        </div>
    )
}
export default App;
